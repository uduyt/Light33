<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>Plano de localización</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>





        <!--content=contenido de la página-->
<div id="content">




<h3>PLANO DE LOCALIZACIÓN</h3>
<img src="/images/plano.jpg">


</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
