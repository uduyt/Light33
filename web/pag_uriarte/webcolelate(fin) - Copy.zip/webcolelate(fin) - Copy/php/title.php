
  <link href="/imports/style.css" rel="stylesheet" type="text/css" media="screen"  />
  <script src="/imports/jquery.js"></script>
  <script type="text/javascript" src="/imports/swfobject.js"></script>
 <script type="text/javascript" src="/imports/jsuriarte.js"></script>


  <link rel="shortcut icon" sizes href="/images/logo_gif.gif" type="image/gif" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
