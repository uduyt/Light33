<div id="color1">
</div>
<div id="wrapper">



    <!--header-->
    <div id="header">
	<img alt="espere, porfavor" id="frontimg" width="800"  src="/images/img05.jpg">
        <p id="ptitle">I.E.S. Francisco Javier de Uriarte</p>

    </div>
    <!--/header-->
	   <!--page-->   
    <div id="page">
