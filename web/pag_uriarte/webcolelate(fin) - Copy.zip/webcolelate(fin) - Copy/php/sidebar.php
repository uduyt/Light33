
	<!--sidebar-->
<div id="sidebar">

	<div id="logosb">
		<img alt="espere, porfavor"   width="200" height="241" src="/images/logoXaniversario.png" />
	</div>
	<!--/logosb-->
        
	<div id="menu">
    

		<!--menu1-->
		<div class="dt" id="menu1" onmouseover='mouseoverdt(this,"1")' onmouseout='mouseoutdts(this)' onclick='mouseclicdt(this,"1")'>
			<a href="/index.php">P&Aacute;GINA PRINCIPAL  </a>
		</div>


		<!--menu2-->
		<div class="dt" id="menu2" onmouseover='mouseoverdt(this,"2")' onmouseout='mouseoutdt("2")' onclick='mouseclicdt(this,"2")'>
			<p> INFORMACI&Oacute;N GENERAL <img id="arr2" class="arr" src="/images/arrow-right.png" alt="" height="20" width="20"> </p>
		</div>
			<!--smenu2-->
			<div class="dd">
				<ul id="umenu2">
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' title="Historia de Francisco Javier de Uriarte"> <a href="/informacion_general/uriarte.php">Javier de Uriarte</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' ><a href="/informacion_general/instalaciones.php">Instalaciones del centro</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' ><a href="/informacion_general/localizacion.php">Plano de localizaci&oacute;n</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' title="Guia de derechos y responsabilidades de las familias andaluzas en la educaci&oacute;n"><a href="/informacion_general/guiafamilias.pdf" target="_blank">Guia</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' ><a href="/informacion_general/avisolegal.php">Aviso legal</a></li>
				</ul>
			</div>


		<!--menu3-->
		<div class="dt" id="menu3" onmouseover='mouseoverdt(this,"3")' onmouseout='mouseoutdt("3")' onclick='mouseclicdt(this,"3")'>
			<p>ESTRUCTURA ORGANIZATIVA <img id="arr3" class="arr" src="/images/arrow-right.png" alt="" height="20" width="20"> </p>
		</div>
			<!--smenu3-->
			<div class="dd">
				<ul id="umenu3">
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/estructura_organizativa/equipodirectivo.php">Equipo directivo</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/estructura_organizativa/consejoescolar.php">Consejo escolar</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/estructura_organizativa/claustro.php">Claustro de profesores</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/estructura_organizativa/tutores.php">Profesores tutores</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/estructura_organizativa/departamentos.php">Departamentos</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/estructura_organizativa/secretaria.php">Secretar&iacute;a</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' title="Normas b&aacute;sicas de convivencia" ><a href="/estructura_organizativa/normasconvivencia.pdf" target=_blank>Normas</a></li>
				</ul>
			</div>


		<!--menu4-->
		<div class="dt" id="menu4" onmouseover='mouseoverdt(this,"4")' onmouseout='mouseoutdt("4")' onclick='mouseclicdt(this,"4")'>
			<p>INFORMACI&Oacute;N ACAD&Eacute;MICA <img id="arr4" class="arr" src="/images/arrow-right.png" alt="" height="20" width="20"> </p>
		</div>
			<!--smenu4-->
			<div class="dd">
				<ul id="umenu4" onmouseout="mouseoutu(this,'menu4')">
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="/informacion_academica/horarios_grupos.pdf" target=_blank>Horarios de clase</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Calendario escolar 2012/2013" ><a href="/informacion_academica/calendario.php">Calendario escolar</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="recuperaci&oacute;n de asignaturas pendientes" ><a href="/informacion_academica/pendientes.php">Recuperaciones</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Programaciones Did&aacute;cticas" ><a href="/informacion_academica/programaciones.php">Programaciones</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Criterios de evaluaci&oacute;n" ><a href="/informacion_academica/criterios.php">Criterios de evaluaci&oacute;n</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Actividades Complementarias y Extraescolares" ><a href="/informacion_academica/extraescolares.php">Actividades</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Plan de Centro curso 2010-2013 (actualizado a 22 de enero de 2013)" ><a href="/informacion_academica/plandecentro12-13.zip">Plan de centro</a></li>
				</ul>
			</div>


		<!--menu5-->
		<div class="dt" id="menu5" onmouseover='mouseoverdt(this,"5")' onmouseout='mouseoutdt("5")' onclick='mouseclicdt(this,"5")'>
			<p>CURSOS Y GRUPOS <img id="arr5" class="arr" src="/images/arrow-right.png" alt="" height="20" width="20"> </p>
		</div>
			<!--smenu5-->
			<div class="dd">
				<ul id="umenu5" onmouseout="mouseoutu(this,'menu5')">
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos1.htm">1º A</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos2.htm">1º B</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos2.htm">1º C</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos2.htm">2º A</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos3.htm">2º B</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos4.htm">2º C</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos5.htm">3º A</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">3º B</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">3º C</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">4º A</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">4º B</a></li>
					<li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">4º C</a></li>
				</ul>
			</div>


		<!--menu6-->
		<div class="dt" id="menu6" onmouseover='mouseoverdt(this,"6")' onmouseout='mouseoutdt("6")' onclick='mouseclicdt(this,"6")'>
			<p>PROGRAMAS EDUCATIVOS <img id="arr6" class="arr" src="/images/arrow-right.png" alt="" height="20" width="20"> </p>
		</div>
			<!--smenu6-->
			<div class="dd">
				<ul id="umenu6" onmouseout="mouseoutu(this,'menu6')">
					<li title='Plan de igualdad entre hombres y mujeres en la educacion'onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'><a href="/programas_educativos/planigualdad11-12.pdf" target=_blank>Plan de igualdad</a></li>
				</ul>
			</div>
	</div>
	<!--/menu-->
	
	<h2>Contacta con nosotros</h2>
	<div id="contact">
		
		c/ Almirante Suanzes s/n. <br />
		Parcela 11. Poblado Naval. <br />
		11500 - El Puerto de Santa Mar&iacute;a (C&aacute;diz). <br />
		Tel&eacute;fono: 956243434 <br />
		Fax: 956243440 <br />
		11002079.edu@juntadeandalucia.es 	
	</div>
	<!--/contact-->
	
	<div id="webprof">
		<h2>Webs de profesores</h2>
		<ul>
			<li><a href="http://tecnouriarte.blogspot.com/" target="_blank">Blog de Tecnolog&iacute;a (Profesor D. David Moreno)</a></li><hr>
			<li><a href="http://halteriosuriarte.jimdo.com/" target="_blank">Web de CCNN (Profesor D. Luis Guti&eacute;rrez)</a></li><hr>
			<li><a href="http://bitacorauriarte.blogspot.com/" target="_blank">Blog del profesor D. Eduardo L&oacute;pez Prieto</a></li><hr>
			<li><a href="http://www.elorienta.com/uriarte/index.php" target="_blank">Blog de Orientaci&oacute;n (Profesora Dª. Roc&iacute;o Garc&iacute;a Criado)</a></li><hr>
			<li><p> Para el resto de profesores pinchar <a href="claustro.html" >aqu&iacute;</a>.</p></li>			
		</ul>
	</div>
	<!--/webprof-->
	
	<div id="enlacesex">
		<h2>Enlaces externos</h2>
		<ul>
			<li><a href="http://www.juntadeandalucia.es/educacion" target="_blank">Consejer&iacute;a de Educaci&oacute;n</a></li><hr>
			<li><a href="http://www.iesjuanlara.es/" target="_blank">I.E.S. Pintor Juan Lara</a></li><hr>
			<li><a href="http://www.juntadeandalucia.es/averroes/cpmarquesdesantacruz/" target="_blank">C.E.I.P. Marqu&eacute;s de Santa Cruz</a></li><hr>
			<li><a href="http://www.juntadeandalucia.es/educacion/portalseneca/web/pasen/inicio" target="_blank">Plataforma PASEN</a></li><hr>
			<li><a href="http://www.facebook.com/pages/IES-Francisco-Javier-de-Uriarte/537218622969200?ref=ts&fref=ts" target="_blank">P&aacute;gina Facebook del Instituto</a></li>
		</ul>
	</div>
	<!--/enlacesex-->
	
	<div id="otrosb">
		<ul>
			<li><a href="extraescolares.html"><b>ACTIVIDADES EXTRAESCOLARES</b></a></li><hr>
			<li><a href="http://campeonesuriarte.blogspot.com/" target="_blank"><b>NUESTROS CAMPEONES</b></a></li><hr>
			<li><a href="ampa.html"><b>AMPA "LA ODISEA"</b></a></li>
		</ul>
	</div>
	<!--/otrosb-->
	
</div>
	<!--/sidebar-->



 </div>
<!--/wrapper=body entero-->


<script>
window.onload=alert("hi")
window.onload=function onloadd(){
alert("helloo")
h = document.getElementById("sidebar");
q= document.getElementById("content");
if (q.style.height > q.style.minHeight){
h.style.height=q.style.height
}

</script>