<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>I.E.S. Francisco Javier de Uriarte</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>



        <!--content=contenido de la página-->
<div id="content">


<h3>DEPARTAMENTOS Y PROFESORES QUE LOS COMPONEN</h3>
 

Siempre que exista un enlace activo (aparecerá en color verde claro), para consultar una cuestión general del Departamento pinchar sobre el nombre del Departamento. Para consultar una cuestión referente a un profesor concreto (recursos, actividades o tareas dirigidas a sus alumnos, por ejemplo) pinchar sobre el nombre del profesor. <p>

<table border=1> 
<tr>
	<td>  <b>DEPARTAMENTOS</b> </td>
	<td>  <b>PROFESORES</b> </td>
</tr>

<tr> 
	<td>  <b>MATEM&Aacute;TICAS</b> </td>
	<td>  Dª María del Carmen Santos Garc&iacute;a 
		<br> D. Salvador Mart&iacute;n Guzm&aacute;n
		<br> D. Francisco J. Cuesta Mu&ntilde;oz
		<br> Dª Laura Márquez Peña 
	</td> 
</tr>

<tr> 
	<td>  <b>CIENCIAS NATURALES</b> </td>
	<td>  D. Luis Guti&eacute;rrez Bernal
		<br> Dª Pilar Espejo Segura 
		<br> Dª Inmaculada Prieto Nieto 
	</td> 
</tr>

<tr> 
	<td>  <b>TECNOLOG&Iacute;A</b> </td>
	<td>  D. David Moreno Rodr&iacute;guez 
		<br> D. Juan C. Chaves Gallardo 
	</td>
</tr>

<tr> 
	<td>  <b><a href="deplengua.html">LENGUA CASTELLANA Y LITERATURA</a></b> </td>
	<td>  Dª Mar&iacute;a Sagrario Marchena Aparicio
		<br> Dª Lourdes P&eacute;rez M&aacute;rquez
		<br> D. Eduardo López Prieto
	</td>
</tr>

<tr> 
	<td>  <b>CIENCIAS SOCIALES</b> </td>
	<td>  Dª Francisca Cristina Ram&iacute;rez Raposo
		<br> Dª Isabel Mar&iacute;a Rodr&iacute;guez Jim&eacute;nez
		<br> D. Francisco Pérez Alcaide  
	</td>
</tr>

<tr> 
	<td>  <b>LENGUA EXTRANJERA - INGL&Eacute;S</b> </td>
	<td>  Dª Rosa Fern&aacute;ndez Cuevas
		<br> Dª Lourdes Caballero Gal&aacute;n
		<br> Dª Ana García Guerra 
		<br> Dª Isabel Mª Jiménez Salcedo
	</td>
</tr>

<tr>
	<td>  <b>LENGUA EXTRANJERA - FRANC&Eacute;S</b> </td>
	<td>  Dª Jacqueline Postigo Casta&ntilde;o
		<br> Dª Alexandra Campos Aguilar
	</td>
</tr>

<tr> 
	<td>  <b>EDUCACION PL&Aacute;STICA Y VISUAL</b> </td>
	<td>  Dª Mar&iacute;a Jos&eacute; Barbosa Illescas </td>
</tr>

<tr> 
	<td>  <b>M&Uacute;SICA</b> </td>
	<td>  Dª Irene Lucio Maestro  </td>
</tr>

<tr> 
	<td>  <b>EDUCACI&Oacute;N F&Iacute;SICA</b> </td>
	<td>  D. Alfonso Angus Hading-Chalamet Garc&iacute;a 
		<br> D. Diego J. Morales Gutiérrez 
	</td>
</tr>

<tr> 
	<td>  <b>ORIENTACI&Oacute;N</b> </td>
	<td>  Dª Mª Pilar Mart&iacute;nez Infante
		<br> Dª Mª Rocío García Criado 
	</td>
</tr>

<tr> 
	<td>  <b>RELIGI&Oacute;N</b> </td>
	<td>  Dª María del Carmen Aranda Linares </td>
</tr> 

</table> 







</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
