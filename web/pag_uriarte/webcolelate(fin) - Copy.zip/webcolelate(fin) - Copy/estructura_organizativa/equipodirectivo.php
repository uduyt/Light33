<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
	<title>Equipo directivo</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>

        <!--content=contenido de la página-->
<div id="content">


<h3>EQUIPO DIRECTIVO</h3>

Directora: Doña Rocío García Criado. <br>
Correo electrónico: direccion.uriarte@gmail.com <br>
Horario de atención : De lunes a viernes de 13,45 a 14,45.Previa cita<br>
<br>
Jefa de Estudios: Doña Irene Lucio Maestro. <br>
Correo electrónico: lucio.irene@gmail.com <br>
Horario de atención : De lunes a viernes de 08,15 a 09,15.Previa cita<br>
<br>
Secretaria: Doña Rosa Fernández Cuevas.<br>
<br>
Correo electrónico de secretaría: myriam.uriarte@gmail.com<br>
<br>
Horario de atención de secretaría: Myriam Solórzano - De lunes a viernes de 9,00 a 10,00 y de 13,00 a 14,30.







</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
