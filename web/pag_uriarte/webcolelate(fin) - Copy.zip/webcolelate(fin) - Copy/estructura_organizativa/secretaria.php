<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>I.E.S. Francisco Javier de Uriarte</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>





        <!--content=contenido de la página-->
<div id="content" style="text-align:left">




<h3>SECRETARÍA</h3>


				

<p>SECRETARIA: Dª Rosa Fernández Cuevas </p>

<p>ADMINISTRATIVA: Dº Jose Antonio Rebollo Leiva</p>

<p>Correo electrónico de secretaría: josea.rebollo@juntadeandalucia.es </p>

<p>Horario de atención de secretaría: Jose Antonio Rebollo Leiva - De lunes a viernes de 9,00 a 10,00 y de 13,00 a 14,30.</p>


 
 
 
 
</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
