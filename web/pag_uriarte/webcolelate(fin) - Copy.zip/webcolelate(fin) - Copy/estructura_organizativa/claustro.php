<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>I.E.S. Francisco Javier de Uriarte</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>





        <!--content=contenido de la página-->
<div id="content">

<h3>CLAUSTRO DE PROFESORES</h3>

<table border=1>

<tr> 
	<td> <b>DEPARTAMENTOS</b></td>
	
	<td> <b>PROFESORES</b></td>
</tr>


<tr>
	<td>  <b>MATEM&Aacute;TICAS</b> </td>
	
	<td>  Dª María del Carmen Santos Garc&iacute;a 
		<br> D. Salvador Mart&iacute;n Guzm&aacute;n
		<br> D. Francisco J. Cuesta Mu&ntilde;oz 
		<br><a href="https://sites.google.com/site/laumarpen/home/" target="_blank">  Dª Laura Márquez Peña </a>
	</td> 
</tr>

<tr>
	<td>  <b>CIENCIAS NATURALES</b> </td>
	
	<td> <a href="http://halteriosuriarte.jimdo.com/" target="_blank">D. Luis Gutiérrez Bernal </a>
		<br> Dª Pilar Espejo Segura <br> Dª Inmaculada Prieto Nieto
	</td>
</tr>

<tr>
	<td>  <b>TECNOLOG&Iacute;A</b> </td>
	
	<td>  <a href="http://tecnouriarte.blogspot.com/" target="_blank">D. David Moreno Rodr&iacute;guez</a>
		<br> D. Juan C. Chaves Gallardo
	</td>
</tr>

<tr>
	<td>  <b>LENGUA CASTELLANA Y LITERATURA</b></td>
	
	<td>  Dª Mar&iacute;a Sagrario Marchena Aparicio
		<br> Dª Lourdes P&eacute;rez M&aacute;rquez
		<br> <a href="http://bitacorauriarte.blogspot.com.es/" target="_blank">D. Eduardo López Prieto </a>
	</td>
</tr>

<tr>
	<td>  <b>CIENCIAS SOCIALES</b> </td>
	
	<td>  Dª Francisca Cristina Ram&iacute;rez Raposo
		<br> Dª Isabel Mar&iacute;a Rodr&iacute;guez Jim&eacute;nez
		<br> D. Francisco Pérez Alcaide 
	</td> 
</tr>

<tr>
	<td>  <b>LENGUA EXTRANJERA - INGL&Eacute;S</b></td>
	
	<td>  Dª Rosa Fern&aacute;ndez Cuevas
		<br> Dª Lourdes Caballero Gal&aacute;n
		<br> Dª Ana García Guerra
		<br> Dª Isabel Mª Jiménez Salcedo
	</td>
</tr>

<tr>	
	<td>  <b>LENGUA EXTRANJERA - FRANC&Eacute;S</b> </td> 
	
	<td>  Dª Jacqueline Postigo Casta&ntilde;o
		<br> Dª Alexandra Campos Aguilar
	</td>
</tr>

<tr> 
	<td>  <b>EDUCACION PL&Aacute;STICA Y VISUAL</b> </td>
	
	<td>  Dª Mar&iacute;a Jos&eacute; Barbosa Illescas </td>
</tr>

<tr>
	<td>  <b>M&Uacute;SICA</b> </td>
	
	<td>  Dª Irene Lucio Maestro </td>
</tr>

<tr> 
	<td><b>EDUCACI&Oacute;N F&Iacute;SICA</b></td>
	
	<td>  D. Alfonso Angus Hading-Chalamet Garc&iacute;a 
		<br> D. Diego J. Morales Gutiérrez
	</td>
</tr>

<tr> 
	<td>  <b>ORIENTACI&Oacute;N</b> </td>
	
	<td>  <a href="http://orientacionuriarte.blogspot.com.es//" target="_blank">  Dª Mª Rocío García Criado </a>
		<br> Dª Mª Pilar Mart&iacute;nez Infante
	</td>
</tr>

<tr>
	<td>  <b>RELIGI&Oacute;N</b> </td>
	
	<td>  Dª María del Carmen Aranda Linares </td>
</tr> 

</table>


</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
