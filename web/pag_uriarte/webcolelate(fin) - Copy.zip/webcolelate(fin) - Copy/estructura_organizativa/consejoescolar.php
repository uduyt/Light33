<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>Consejo Escolar</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>
        <!--content=contenido de la página-->
<div id="content">

<h3>CONSEJO ESCOLAR</h3>


<div style="background-color:#ffffff;width:393px;height:324px;margin-left:auto;margin-right:auto;">
	<div id="flashcontent">
		<object align="middle" id="reproductorEducacion4" height="323" width="393" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000">
			<param value="always" name="allowScriptAccess"></param>
			<param value="true" name="allowFullScreen"> </param>
			<param name="movie" value="http://www.juntadeandalucia.es/educacion/mediva/swf/reproductorIntegracion.swf?ruta_video=http://ondemand.jaedu.ondemand.flumotion.com/jaedu/ondemand/video/1351513753597.mp4.flv&local=1&colorPrincipal=0x4AC1EB&colorSecundario=0x5BB500&rutaAbsoluta=http://www.juntadeandalucia.es/educacion/mediva/"> </param>
			<param value="high" name="quality"></param>
			<param value="#ffffff" name="bgcolor"></param>
			<embed pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" swLiveConnect="true" allowScriptAccess="sameDomain" align="middle" allowFullScreen="true" name="reproductorEducacion4" height="323" width="393" bgcolor="#ffffff" quality="high" src="http://www.juntadeandalucia.es/educacion/mediva/swf/reproductorIntegracion.swf?ruta_video=http://ondemand.jaedu.ondemand.flumotion.com/jaedu/ondemand/video/1351513753597.mp4.flv&local=1&colorPrincipal=0x4AC1EB&colorSecundario=0x5BB500&rutaAbsoluta=http://www.juntadeandalucia.es/educacion/mediva/"></embed>
		</object>
	</div>
</div>


</br>
<table border=1 >
	<tr>
		<td>SECTOR</td> 
		<td>MIEMBRO</td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Equipo Directivo </td>
		<td> <font face=verdana size=2> García Criado, Rocío (Directora) </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Equipo Directivo </td>
		<td> <font face=verdana size=2> Lucio Maestro, Irene (Jefa de Estudios) </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Equipo Directivo </td>
		<td> <font face=verdana size=2> Fernández Cuevas, Rosa (Secretaria) </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Profesorado </td> 
		<td> <font face=verdana size=2> Caballero Galán, Lourdes </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Profesorado </td> 
		<td> <font face=verdana size=2> Martín Guzmán, Salvador </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Profesorado </td>
		<td> <font face=verdana size=2> Aranda Linares, María del Carmen </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Profesorado </td>
		<td> <font face=verdana size=2> Marchena Aparicio, Sagrario </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Profesorado </td>
		<td> <font face=verdana size=2> Martínez Infante, Pilar </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Profesorado </td>
		<td> <font face=verdana size=2> Santos García, María del Carmen </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Madres/Padres/Tutores </td>
		<td> <font face=verdana size=2> Gutiérrez García, María Aránzazu </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Madres/Padres/Tutores </td>
		<td> <font face=verdana size=2> Delgado Roig, Pedro Luis </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Madres/Padres/Tutores </td>
		<td> <font face=verdana size=2> Morell Sastre, Inmaculada </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Madres/Padres/Tutores </td>
		<td> <font face=verdana size=2> Gómez de Ramón Sánchez, María Elena </td>
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Representante de la A.M.P.A. mayoritaria </td> 
		<td> <font face=verdana size=2> Posada Novoa, Manuel </td> 
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Alumnado </td> 
		<td> <font face=verdana size=2> Peñuelas García, Ignacio </td> 
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Alumnado </td> 
		<td> <font face=verdana size=2> Romero Vázquez, Joel </td> 
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Alumnado </td> 
		<td> <font face=verdana size=2> Carrero Blanco Gutiérrez, Paloma </td> 
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Alumnado </td> 
		<td> <font face=verdana size=2> Teppe, Xavier </td> 
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Alumnado </td> 
		<td> <font face=verdana size=2> Osborne Rosso, Ana </td> 
	</tr>

	<tr> 	
		<td> <font face=verdana size=2> Personal Admón. y Servicios </td> 
		<td> <font face=verdana size=2> Carrero-Blanco Velázquez, Guillermo </td> 
	</tr>

	<tr> 
		<td> <font face=verdana size=2> Ayuntamiento </td> 
		<td> <font face=verdana size=2> Rodríguez López de Medina, Marta </td> 
	</tr> 
</table>
<!--/tableSector-Miembro-->

</br>

ÚLTIMAS NOTICIAS REFERENTES A LAS ELECCIONES AL CONSEJO ESCOLAR CURSO 2012

<p>
	El 12 de noviembre se celebrarán las elecciones a Consejos Escolares para el año 2012 para los sectores del profesorado, personal de administración y servicios, personal de atención educativa complementaria y del alumnado de los centros docentes sostenidos con fondos públicos de la Comunidad Autónoma de Andalucía.
</p>

<p>
	La Dirección General de Participación y Equidad comunica que próximamente se publicará en BOJA la Resolución de 23 de octubre de 2012 que modificará el calendario definido en la resolución de 12 de septiembre de 2012, en concreto en lo que atañe al día previsto para la votación del profesorado, del personal de administración y servicios y, en su caso, del personal de atención educativa complementaria, que estaba previsto fuera el día 14 de noviembre. Se adelanta este día para hacerlo coincidir con el día que el calendario establece para la votación del sector del alumnado, en concreto el día 12 del mismo mes, con lo que, además, se pretende mantener la previsión inicial para que el Consejo Escolar que salga de dicho proceso se constituya, como máximo, el día 30 de Noviembre de 2012.
</p>

<p>
	<a href="Convocatorias_de_elecciones.pdf" target=_blank>Documento de convocatoria de elecciones</a>
</p>

<p>
	<a href="Listado_provisional_candidatos.pdf" target=_blank>Listado provisional de candidatos</a>
</p>

<p>
	POSIBILIDAD DE VOTO NO PRESENCIAL EN LAS ELECCIONES AL CONSEJO ESCOLAR 2012
</p>

<p>
	Estimadas familias:
</p>

<p>
	Como ya se había indicado anteriormente, estamos inmersos en el proceso electoral para la renovación  y constitución del Consejo Escolar de nuestro Instituto. Les comunico ahora,  con la finalidad de favorecer la participación del todos los sectores en las elecciones, tal y como se recoge en la normativa, la posibilidad del voto no presencial por parte de los padres, madres y representantes legales del alumnado.
</p>

<p>
	A tal efecto, la Junta Electoral les remite, la papeleta de voto indicándose en la misma el nº máximo de personas candidatas que puedan ser votadas. (Se adjunta <a href="papeleta_voto_padresmadrestutores.pdf" target=_blank>archivo</a>
</p>

<p>
	Para garantizar el secreto del voto, la identidad de la persona votante y evitar posibles duplicidades se utilizará el sistema de doble sobre. Un sobre exterior se dirigirá por correo certificado a la Mesa electoral de madres, padres y representantes legales del alumnado, o bien, se entregará (pueden hacerlo por medio de sus hijos o por alguna persona en representación del interesado, junto a una autorización a dicha persona para hacer entrega del voto) durante los cinco días hábiles anteriores al de la votación, sin perjuicio de que se pueda presentar el mismo día de la votación, antes de la realización del escrutinio,  a la persona titular del la Dirección del centro que lo custodiará hasta su entrega a dicha Mesa electoral.
</p>

<p>
	El sobre exterior contendrá firma manuscrita y coincidente con la que aparece en el documento de identificación que aporte, fotocopia del DNI o de otro documento acreditativo equivalente, y un segundo sobre en blanco y cerrado en cuyo interior se habrá incluido la papeleta de voto.
</p>

<p>
	En el caso de que el sobre al que se refiere el párrafo anterior sea entregado a la persona titular de la Dirección del centro, ésta expedirá un documento con un recibí como justificante de la entrega.
</p>

<p>
	La Mesa electoral comprobará que las personas votantes que utilicen la modalidad de voto no presencial, están incluidos en el censo electoral. Los votos recibidos una vez finalizado el escrutinio no serán tenidos en cuenta.
</p>

<p>
	El Puerto de Santa María, a 30 de octubre de 2012
</p>

<p>Atentamente </p>

<p>Rocío García Criado </p>
<p>Presidenta de la Junta Electoral </p>

<p><b>COMPONENTES DE LA MESA ELECTORAL DEL CONSEJO ELECTORAL</b></p>

<p>Pinchar en el siguiente <a href="mesa_electoral_C_E.pdf" target=_blank>enlace</a>.</p>

<p><b>ACTAS DEFINITIVAS DE CONSTUTICIÓN DE LA MESA Y ELECCIÓN DE CANDIDATOS</b></p>

<p>Pinchar en el siguiente <a href="actas_mesas_elecciones_CE.pdf" target=_blank>enlace</a>.</p>

















</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
