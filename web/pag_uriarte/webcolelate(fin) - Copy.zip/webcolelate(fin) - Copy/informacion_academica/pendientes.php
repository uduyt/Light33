<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>I.E.S. Francisco Javier de Uriarte</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>





        <!--content=contenido de la página-->
<div id="content" style="text-align:left">

<h3>RECUPERACIÓN DE ASIGNTURAS PENDIENTES</h3>



<p> - <a href="recuperaciones/Anexo1CSGH.pdf" target=_blank>Ciencias Sociales</a></p> 
<p> - <a href="recuperaciones/Anexo1CCNN.pdf" target=_blank>Ciencias Naturales</a></p> 
<p> - <a href="recuperaciones/Anexo1MAT.pdf" target=_blank>Matemáticas</a></p> 
<p> - <a href="recuperaciones/Anexo1LCL.pdf" target=_blank>Lengua y Literatura</a></p> 
<p> - <a href="recuperaciones/Anexo1EF.pdf" target=_blank>Educación Física</a></p> 
<p> - <a href="recuperaciones/Anexo1EPV.pdf" target=_blank>Educación Plástica</a></p> 
<p> - <a href="recuperaciones/Anexo1MUS.pdf" target=_blank>Música</a></p> 
<p> - <a href="recuperaciones/Anexo1ING.pdf" target=_blank>Inglés</a></p> 
<p> - <a href="recuperaciones/Anexo1FR.pdf" target=_blank>Francés</a></p> 
<p> - <a href="recuperaciones/Anexo1TEC.pdf" target=_blank>Tecnología</a></p> 
<p> - <a href="recuperaciones/Anexo1ORI.pdf" target=_blank>Orientación</a></p> 
<p> - <a href="recuperaciones/Anexo1REL.pdf" target=_blank>Religión</a></p> 
 

</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
