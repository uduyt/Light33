<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>I.E.S. Francisco Javier de Uriarte</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>





        <!--content=contenido de la página-->
<div id="content" style="text-align:left">

<h3>PROGRAMACIONES DIDÁCTICAS</h3>

<p> - <a href="programaciones/ProgCSGH12-13.pdf" target=_blank>Ciencias Sociales</a></p> 
<p> - <a href="programaciones/ProgCCNN12-13.pdf" target=_blank>Ciencias Naturales</a></p> 
<p> - <a href="programaciones/ProgMAT12-13.pdf" target=_blank>Matemáticas</a></p> 
<p> - <a href="programaciones/ProgEPV12-13.pdf" target=_blank>Educación Plástica</a></p> 
<p> - <a href="programaciones/ProgMUS12-13.pdf" target=_blank>Música</a></p> 
<p> - <a href="programaciones/ProgEF12-13.pdf" target=_blank>Educación Física</a></p> 
<p> - <a href="programaciones/ProgING12-13.pdf" target=_blank>Inglés</a></p> 
<p> - <a href="programaciones/ProgFR12-13.pdf" target=_blank>Francés</a></p> 
<p> - <a href="programaciones/ProgLCL12-13.pdf" target=_blank>Lengua y Literatura</a></p> 
<p> - <a href="programaciones/ProgTEC12-13.pdf" target=_blank>Tecnología</a></p> 
<p> - <a href="programaciones/ProgREL12-13.pdf" target=_blank>Religión</a></p> 
 

</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>
