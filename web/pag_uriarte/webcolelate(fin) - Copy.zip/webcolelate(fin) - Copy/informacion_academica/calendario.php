<!DOCTYPE html>
<html>
	<head>
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/title.php'; ?>
		<title>I.E.S. Francisco Javier de Uriarte</title>
	</head>

	<body>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte1.php';?>





        <!--content=contenido de la página-->
<div id="content">

<h3>CALENDARIO ESCOLAR 2012/13</h3>


<table border=1> 
<tr> <td>  17 de septiembre </td> 
	<td>  Inicio del curso </td> 
</tr>
	
<tr> 
	<td>  12 de octubre </td>
	<td>  Día del Pilar. Festivo a nivel nacional. </td> 
</tr>

<tr> 
	<td>  1 de noviembre </td>
	<td>  D&iacute;a de Todos los Santos. Festivo a nivel nacional. </td>	  
</tr> 

<tr> 
	<td>  2 de noviembre </td> 
	<td>  Día no lectivo a nivel provincial. </td> 
</tr> 

<tr> 
	<td>  6 de diciembre </td>
	<td>  D&iacute;a de la Constituci&oacute;n. Festivo a nivel nacional. </td>
</tr> 

<tr> 
	<td>  7 de diciembre </td> 
	<td>  No lectivo a nivel local. </td> 
</tr> 

<tr> 
	<td>  21 de diciembre </td>
	<td>  Entrega de notas de la 1ª evaluaci&oacute;n </td> 
</tr> 

<tr> 
	<td>  24 de diciembre al 7 de enero </td>
	<td>  Vacaciones de Navidad. No lectivos. </td> 
</tr>

<tr>
	<td>  27 de febrero </td>
	<td>  D&iacute;a no  lectivo a nivel local. </td>
</tr>

<tr> 
	<td>  28 de febrero </td>
	<td>  D&iacute;a de Andaluc&iacute;a. Festivo a nivel autonómico. </td> 
</tr>  

<tr> 
	<td>  1 de marzo </td> 
	<td>  D&iacute;a de la Comunidad Educativa. No lectivo a nivel provincial. </td> 
</tr> 

 <tr> 
	<td>  22 de marzo </td>
	<td>  Entrega de notas de la 2ª evaluaci&oacute;n </td> 
</tr> 

<tr> 
	<td>  25 de marzo al 31 de marzo </td> 
	<td>  Vacaciones de Semana Santa. No lectivos. </td> 
</tr>  

<tr>
	<td>  26 de abril </td> 
	<td>  Viernes de Feria no  lectivo a nivel local.</td> 
</tr>

<tr> 
	<td>  29 de abril </td>
	<td>  Lunes de Feria no  lectivo a nivel local.</td> 
</tr>

<tr> 
	<td>  30 de abril </td> 
	<td>  D&iacute;a no  lectivo a nivel local.</td> 
</tr> 

<tr> 
	<td>  1 de mayo </td>
	<td>  D&iacute;a del Trabajo. Festivo a nivel nacional. </td> 
</tr>

<tr> 
	<td>  25 de junio </td> 
	<td>  Último día de clases </td> 
</tr> 
</table>




</div>
		<!--/content=contenido de la página-->

		
		
		
		
		
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/body_parte2.php'; ?> 
		<?php include $_SERVER['DOCUMENT_ROOT'] . '/php/sidebar.php'; ?>
  
	</body>
</html>








