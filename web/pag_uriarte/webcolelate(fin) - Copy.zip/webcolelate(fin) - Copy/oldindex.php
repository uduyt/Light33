<!DOCTYPE html>
<html>
<head>
    <title>I.E.S. Francisco Javier de Uriarte</title><script type="text/javascript" src="swfobject.js"></script><script type="text/javascript" src="jsuriarte.js"></script> <script type="text/javascript" src="jquery.js"></script> <link href="style.css" rel="stylesheet" type="text/css" media="screen" />

</head>

<body >
<!--wrapper=body entero-->
<div id="wrapper">



    <!--header-->
    <div id="header">
        <p id="htitle"> Francisco Javier de Uriarte</p>
        <img alt="espere, porfavor" id="frontimg" height="193" width="740" src="images/img05.jpg">
    </div>
    <!--/header-->

    <!--page-->
    <div id="page">
    
	

        <!--content=contenido de la p�gina-->
        <div id="content">
            <p> this is the content</p>
        </div>
	   <!--/content=contenido de la p�gina-->


	   <!--footer-->
        <div id="footer">
            <p> this is a footer</p>
        </div>
	   <!--/footer-->
	
    </div>
    <!--/page-->
    
	<!--sidebar-->
    <div id="sidebar">



        
<div id="menu">
    <div id="logogif">
        <img alt="espere, porfavor" style="float:right; margin-right:25px"  width="150" height="150" src="images/logo_gif.gif" />
    </div>

<!--menu1-->
<div class="dt" id="menu1" onmouseover='mouseover(this,"smenu1")' onmouseout='mouseout(this,"smenu1")' onclick='mouseclic(this,"smenu1")'>
    <a href="prototipo_nueva.html">P&Aacute;GINA PRINCIPAL</a>
</div>


<!--menu2-->
<div class="dt" id="menu2" onmouseover='mouseover(this,"smenu2")' onmouseout='mouseout(this,"smenu2")' onclick='mouseclic(this,"smenu2")'>
    <a>INFORMACI&Oacute;N GENERAL</a>
</div>
<!--smenu2-->
    <div class="dd" id="smenu2">
        <ul id="umenu2" onmouseout="mouseoutu(this,'menu2')">
            <li  onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' title="Historia de Francisco Javier de Uriarte"> <a id="lx21" href="informacion_general/uriarte.html">Javier de Uriarte</a></li>

            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' ><a href="informacion_general/instalaciones.html">Instalaciones del centro</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' ><a href="informacion_general/localizacion.html">Plano de localizaci&oacute;n</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' title="Guia de derechos y responsabilidades de las familias andaluzas en la educaci&oacute;n"><a href="informacion_general/guiafamilias.pdf" target=_blank>Guia</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' ><a href="informacion_general/avisolegal.html">Aviso legal</a></li>
        </ul>
	</div>


<!--menu3-->
<div class="dt" id="menu3" onmouseover='mouseover(this,"smenu3")' onmouseout='mouseout(this,"smenu3")' onclick='mouseclic(this,"smenu3")'>
    <a>ESTRUCTURA ORGANIZATIVA</a>
</div>
<!--smenu3-->
    <div class="dd" id="smenu3">
        <ul id="umenu3" onmouseout="mouseoutu(this,'menu3')">
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="estructura_organizativa/equipodirectivo.html">Equipo directivo</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="estructura_organizativa/consejoescolar.html">Consejo escolar</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="estructura_organizativa/claustro.html">Claustro de profesores</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="estructura_organizativa/tutores.html">Profesores tutores</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="estructura_organizativa/departamentos.html">Departamentos</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="estructura_organizativa/secretaria.html">Secretar&iacute;a</a></li>
           <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)' title="Normas b&aacute;sicas de convivencia" ><a href="estructura_organizativa/normasconvivencia.pdf" target=_blank>Normas</a></li>
        </ul>
    </div>


<!--menu4-->
<div class="dt" id="menu4" onmouseover='mouseover(this,"smenu4")' onmouseout='mouseout(this,"smenu4")' onclick='mouseclic(this,"smenu4")'>
    <a>INFORMACI&Oacute;N ACAD&Eacute;MICA</a>
</div>
<!--smenu4-->
    <div class="dd" id="smenu4">
        <ul id="umenu4" onmouseout="mouseoutu(this,'menu4')">
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="informacion_academica/horarios_grupos.pdf" target=_blank>Horarios de clase</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Calendario escolar 2012/2013" ><a href="informacion_academica/calendario.html">Calendario escolar</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="recuperaci&oacute;n de asignaturas pendientes" ><a href="informacion_academica/pendientes.html">Recuperaciones</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Programaciones Did&aacute;cticas" ><a href="informacion_academica/programaciones.html">Programaciones</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Criterios de evaluaci&oacute;n" ><a href="informacion_academica/criterios.html">Criterios de evaluaci&oacute;n</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Actividades Complementarias y Extraescolares" ><a href="informacion_academica/extraescolares.html">Actividades</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'title="Plan de Centro curso 2010-2013 (actualizado a 22 de enero de 2013)" ><a href="informacion_academica/Plandecentro12-13.zip">Plan de centro</a></li>
        </ul>
	</div>


<!--menu5-->
<div class="dt" id="menu5" onmouseover='mouseover(this,"smenu5")' onmouseout='mouseout(this,"smenu5")' onclick='mouseclic(this,"smenu5")'>
    <a>CURSOS Y GRUPOS</a>
</div>
<!--smenu5-->
    <div class="dd" id="smenu5">
        <ul id="umenu5" onmouseout="mouseoutu(this,'menu5')">
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos1.htm">1� A</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos2.htm">1� B</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos2.htm">1� C</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos2.htm">2� A</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos3.htm">2� B</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos4.htm">2� C</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos5.htm">3� A</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">3� B</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">3� C</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">4� A</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">4� B</a></li>
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos6.htm">4� C</a></li>
        </ul>
    </div>


<!--menu6-->
<div class="dt" id="menu6" onmouseover='mouseover(this,"smenu6")' onmouseout='mouseout(this,"smenu6")' onclick='mouseclic(this,"smenu6")'>
    <a href="validacion/validacion.html">PROGRAMAS EDUCATIVOS</a>
</div>
<!--smenu6-->
    <div class="dd" id="smenu6">
        <ul id="umenu6" onmouseout="mouseoutu(this,'menu6')">
            <li onmouseover='mouseoverli(this)' onmouseout='mouseoutli(this)'  ><a href="vinculos/vinculos1.htm">1� A</a></li>
        </ul>
    </div>




    </div>
</div>
	<!--/sidebar-->



 </div>
<!--/wrapper=body entero-->
</body>
</html>
